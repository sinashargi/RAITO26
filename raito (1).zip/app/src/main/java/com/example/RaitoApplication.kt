package com.example

import android.app.Application
import com.example.data.TeleguardDatabase
import com.example.data.TeleguardRepository

class RaitoApplication : Application() {
    val database by lazy { TeleguardDatabase.getInstance(this) }
    val repository by lazy { TeleguardRepository(database.teleguardDao) }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: RaitoApplication
            private set
    }
}
